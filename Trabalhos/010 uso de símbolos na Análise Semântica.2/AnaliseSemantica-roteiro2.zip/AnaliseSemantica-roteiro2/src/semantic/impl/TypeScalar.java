package semantic.impl;

public class TypeScalar extends TypeClass {
	
	public boolean isScalar() {
		return true;
	}

}
