package semantic.interfaces;

public interface TypeChar extends TypeScalar {

}
