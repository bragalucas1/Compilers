package semantic.interfaces;

public interface SymbolVariable
extends SemanticSymbol {
	
	public int getLevel();

	public int getOffset();

}
