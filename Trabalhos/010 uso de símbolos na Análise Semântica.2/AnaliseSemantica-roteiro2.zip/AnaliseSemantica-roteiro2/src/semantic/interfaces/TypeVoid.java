package semantic.interfaces;

public interface TypeVoid
extends TypeClass {

}
