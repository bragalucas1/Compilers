package semantic.interfaces;

public interface TypeInteger
extends TypeScalar {

}
