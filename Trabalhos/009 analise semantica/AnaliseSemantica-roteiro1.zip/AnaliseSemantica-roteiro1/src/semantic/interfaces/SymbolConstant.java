package semantic.interfaces;

public interface SymbolConstant
extends SemanticSymbol {
	
	Object getValue();

}
