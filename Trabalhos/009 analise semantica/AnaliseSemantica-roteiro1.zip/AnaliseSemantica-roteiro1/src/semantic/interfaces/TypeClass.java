package semantic.interfaces;

public interface TypeClass extends SemanticType {

	public Environment getEnvironment();
	
	public void setEnvironment(Environment env);
	
}
