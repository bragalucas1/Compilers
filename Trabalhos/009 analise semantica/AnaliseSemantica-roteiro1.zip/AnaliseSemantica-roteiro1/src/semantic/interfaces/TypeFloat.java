package semantic.interfaces;

public interface TypeFloat
extends TypeScalar {

}
