package semantic.interfaces;

public interface TypeBoolean extends TypeScalar {

}
