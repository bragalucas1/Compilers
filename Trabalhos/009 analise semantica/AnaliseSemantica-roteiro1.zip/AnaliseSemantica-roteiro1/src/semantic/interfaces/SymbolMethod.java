package semantic.interfaces;

public interface SymbolMethod
extends SemanticSymbol {

}
