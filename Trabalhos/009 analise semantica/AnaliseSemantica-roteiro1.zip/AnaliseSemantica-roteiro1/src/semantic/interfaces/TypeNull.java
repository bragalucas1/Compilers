package semantic.interfaces;

public interface TypeNull
extends SemanticType {

}
