package semantic.interfaces;

public interface TypeScalar extends TypeClass {

}
