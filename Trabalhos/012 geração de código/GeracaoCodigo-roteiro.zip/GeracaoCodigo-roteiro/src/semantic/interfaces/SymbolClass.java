package semantic.interfaces;

public interface SymbolClass
extends SemanticSymbol {
	
}
