package semantic.interfaces;

public interface TypeArray
extends SemanticType {
	
	public SemanticType getInnerType();

}
